package com.example.finalpidev;

public class RelatedRecordsException extends Exception {
    public RelatedRecordsException(String message) {
        super(message);
    }
}
